#!/bin/bash
#echo "----------------------------------------------------------"
#echo "--  COPY THE JENKINS TOKEN ABOVE!!!"
#echo "----------------------------------------------------------"
#read -p "Once you copy this token, press enter to close this window"
read -p "Now that Jenkins is running, press enter to close this window"
